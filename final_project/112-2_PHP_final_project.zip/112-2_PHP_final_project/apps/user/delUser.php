<?php
    require "../../asset/inc/dblink.inc";
    $delId = $_GET["delId"];
    $sql = "DELETE FROM user WHERE uId = '$delId'";
    if(mysqli_query($link,$sql)){
        echo json_encode(["msg"=>"成功刪除使用者 id=$delId"]);
    }else{
        echo json_encode(["msg"=>"刪除失敗，請稍後再試"]);
    }
?>