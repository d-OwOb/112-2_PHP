<?php
    session_start();
    $inputCode = $_GET["code"];
    $inputCode = strtoupper($inputCode);
    $mail = $_GET["Mail"];
    $varCode = $_SESSION["varCode"];
    $pass=1;


    if($varCode != $inputCode){
        $pass = 0;
    }

    $data =array("pass"=>$pass,"mail"=>$mail);
    echo json_encode($data);
?>