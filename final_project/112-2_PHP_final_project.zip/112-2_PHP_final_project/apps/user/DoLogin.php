<?php
    session_start();
    $uAcc = $_POST["uAcc"];
    require "../../asset/inc/dblink.inc";
    $sql = "SELECT uId FROM user WHERE Account = '$uAcc'";
    $result = mysqli_fetch_assoc(mysqli_query($link,$sql));
    $_SESSION["uId"] = $result["uId"];
    $data = array(
        "isPass"=> 1, 
        "msg" =>1
    );
    echo json_encode($data);
    
?>