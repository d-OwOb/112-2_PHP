<?php
    require "../../asset/inc/dblink.inc";
    $array = array();
    $sql = "SELECT * FROM depts";
    $result = mysqli_query($link,$sql);

    while($rows = mysqli_fetch_assoc($result)){
        $array[] = [$rows["Id"],$rows["Name"]];
    }

    // print_r($array);
    echo json_encode($array);
    
?>
