<?php
    require "../../asset/inc/dblink.inc";
    $id = $_GET["id"];
    $sql ="UPDATE user SET isBaned = '0' WHERE uId='$id'";
    if(mysqli_query($link,$sql)){
        echo json_encode(["msg"=>"成功解禁使用者 id=$id"]);
    }else{
        echo json_encode(["msg"=>"解禁失敗，請稍後再試"]);
    }
?>