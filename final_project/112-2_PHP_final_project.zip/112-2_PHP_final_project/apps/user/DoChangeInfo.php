<?php
    session_start();
    require "../../asset/inc/dblink.inc";
    $newMail = $_SESSION["newMail"];
    $newDept = $_SESSION["newDept"];
    $uId = $_GET["uId"];
    $sql2 = "UPDATE user SET deptId = '$newDept' WHERE uId = $uId";
    $sql1 = "UPDATE user SET mail = '$newMail' WHERE uId = '$uId'";
    if( mysqli_query($link,$sql1) && mysqli_query($link,$sql2)){
        header("Location:userinfo.php?uId=$uId");
    }
   
?>