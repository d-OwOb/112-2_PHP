<?php
            $data=array();
            require "../../asset/inc/dblink.inc";
            $sql = "SELECT CreateDate, COUNT(CreateDate) AS NumOfDate FROM article GROUP BY CreateDate";
            $chart_result = mysqli_query($link, $sql);
            while($rows = mysqli_fetch_assoc($chart_result)){
              $date = $rows["CreateDate"];
              $numOfDate = $rows["NumOfDate"];
              $data[] = [$date , $numOfDate];
            } 
            echo json_encode($data);
?>