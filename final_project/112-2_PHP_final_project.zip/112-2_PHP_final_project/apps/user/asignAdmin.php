<?php
    require "../../asset/inc/dblink.inc";
    $id = $_GET["id"];
    $sql ="UPDATE user SET isAdmin = '1' WHERE uId='$id'";
    if(mysqli_query($link,$sql)){
        echo json_encode(["msg"=>"成功給予管理員權限 id=$id"]);
    }else{
        echo json_encode(["msg"=>"增加失敗，請稍後再試"]);
    }
?>