<?php
    session_start();
    require "../../asset/inc/dblink.inc";
    $uMail = $_POST["uMail"];
    $sql = "SELECT COUNT(*) AS count FROM user WHERE mail = '$uMail'";
    $msg="";
    $isPass = 1;
    $result = (mysqli_fetch_assoc(mysqli_query($link,$sql)));


    if($result["count"] == 0){
        $isPass = 0;
        $msg .= "記錄內無此信箱";
    }else{
        $_SESSION["veri_situation"] = "forgotPassword";
    }

    $data = array(
        'isPass'=>$isPass , 
        'msg'=>$msg
    );
    echo json_encode($data);
?>