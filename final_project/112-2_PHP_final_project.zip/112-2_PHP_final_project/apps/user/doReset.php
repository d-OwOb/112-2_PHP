<?php
    session_start();
    $mail = $_POST["mail"];
    $pass = hash("sha256",$_POST["pass"]);
    $msg="";
    require "../../asset/inc/dblink.inc";
    $sql = "UPDATE user SET Password_hash = '$pass' WHERE mail = '$mail'";
    if(mysqli_query($link,$sql)){
        $msg = "更新成功";
    }else{
        $msg.="更新失敗，請稍後再試";
    }

    $data=array(
        "msg"=> $msg
    );
    $_SESSION["veri_situation"]="normal";
    echo json_encode($data);
?>