<?php
$uAcc = $_GET["uAcc"];
$uMail = $_GET["uMail"];
$msg="";
$isPass=1;
require "../../asset/inc/dblink.inc";

$sql = "SELECT COUNT(*) as count FROM user WHERE Account = '$uAcc'";
$result = mysqli_query($link, $sql);
$count = mysqli_fetch_assoc($result)["count"];

if($count != 0){
    $msg .= "帳號已被使用\n";
    $isPass = 0;
}

$sql = "SELECT COUNT(*) as count FROM user WHERE mail = '$uMail'";
$result = mysqli_query($link, $sql);
$count = mysqli_fetch_assoc($result)["count"];

if($count != 0){
    $msg .= "信箱已被使用\n";
    $isPass = 0;
}


echo json_encode(array("isPass"=>$isPass , "msg"=> $msg));
?>