<?php
    session_start();
    $_SESSION["newMail"] = $_POST["newMail"];
    $_SESSION["newDept"] = $_POST["newDept"];
    $_SESSION["veri_situation"] = "changeInfo";
    $isPass = 1;
    if($_SESSION["veri_situation"] != "changeInfo"){
        $isPass =0;
    }
    echo json_encode(array("isPass"=>$isPass));

?>