<?php
    $uAcc = $_POST["uAcc"];
    $uPass_hash = hash("sha256",$_POST["uPass"]);
    
    $isPass = 1 ;
    $msg="";
    require "../../asset/inc/dblink.inc";
    $sql = "SELECT COUNT(*) AS count FROM user WHERE Account = '$uAcc'";
    if(mysqli_fetch_assoc(mysqli_query($link,$sql))["count"] == 0){
        $isPass = 0;
        $msg .= "使用者不存在";
    }else{
        $sql = "SELECT uId , Password_hash FROM user WHERE Account = '$uAcc'";
        $result = mysqli_fetch_assoc(mysqli_query($link,$sql));
        
        if( $result["Password_hash"] != $uPass_hash){
            $isPass=0;
            $msg.="密碼錯誤";
        }
    }
    $data = array(
        "isPass"=> $isPass , 
        "msg" => $msg
    );
    echo json_encode($data);
?>