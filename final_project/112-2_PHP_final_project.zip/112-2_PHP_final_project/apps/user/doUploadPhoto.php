<?php
session_start();
$uId = $_SESSION["uId"];
$ext = pathinfo($_FILES["newPhoto"]["name"] , PATHINFO_EXTENSION);
$tmp_dirpath = pathinfo($_FILES["newPhoto"]["tmp_name"],PATHINFO_DIRNAME);
$tmp_fullname = pathinfo($_FILES["newPhoto"]["tmp_name"],PATHINFO_BASENAME);
require "../../asset/inc/dblink.inc";

$Path = "../../asset/img/user/$uId/";
if(!file_exists($Path)){
    mkdir($Path);
}
$fileName = "photo_ini.$ext";
$filePath = $Path . $fileName;
if(copy($_FILES["newPhoto"]["tmp_name"],$filePath)){
    echo "檔案上傳成功<br/>";
    unlink($_FILES["newPhoto"]["tmp_name"]);
    //剪成512*512 (謝謝chatGPT)

    $source = $filePath;

    $ext= strtolower($ext);

    switch ($ext) {
        case 'png':
            $img = imagecreatefrompng($source);
            break;
        case 'jpeg':
        case 'jpg':
            $img = imagecreatefromjpeg($source);
            break;
        default:
            exit;
    }
    
    
    $x_ini = imagesx($img);
    $y_ini = imagesy($img);

    // 定义裁减区域
    $width = 512;  // 裁减区域的宽度
    $height = 512;  // 裁减区域的高度
    $x_time = $x_ini/$width; //X是512的幾倍
    $y_time = $y_ini/$height; //Y是512的幾倍
    $time;
    if($x_time >= $y_time){
        $time = $y_time;
    }else{
        $time=$x_time;
    }
    $x = ($x_ini-$width*$time)/2;  // 裁减区域的左上角 x 坐标
    $y = ($y_ini-$height*$time)/2;  // 裁减区域的左上角 y 坐标
    // 创建一个新的真彩色图像
    $crop_img = imagecreatetruecolor($width, $height);
    
    // 裁减图像
    imagecopyresampled($crop_img, $img, 0, 0, $x, $y, $width, $height, $width*$time, $height*$time);
    //刪除舊檔案
    $sql = "SELECT photoPath FROM user WHERE uId = '$uId'";
    $result = mysqli_query($link,$sql);
    $oldimg = mysqli_fetch_assoc($result)["photoPath"];
    if(file_exists($oldimg) && !(strpos($oldimg,"default"))){
        unlink($filePath);
        unlink($oldimg);
        echo "已刪除檔案".$filePath;
        echo "已刪除檔案".$oldimg;
    }    
    // 保存裁减后的图像
    $destination = $Path."photo_512.$ext";
    imagepng($crop_img, $destination);

    // 释放内存
    imagedestroy($img);
    imagedestroy($crop_img);


    $sql = "UPDATE user SET photoPath = '$destination' WHERE uId = '$uId'";
    if(!mysqli_query($link,$sql)){
        echo "更新資料庫失敗";
    }else{
        echo "更新資料庫成功";

        header("Location:userinfo.php?uId=$uId");
    }
}
else{
   echo "檔案上傳失敗<br/>";
}
?>