<?php
    session_start();
    require "../../asset/inc/dblink.inc";
    $id = $_GET["id"];
    $sql = "SELECT Account FROM user WHERE uId='$id'";
    $result = mysqli_fetch_assoc(mysqli_query($link,$sql))["Account"];
    $msg='';
    if($result == "broth1230" || $result == "a1113302" ||$result == "a1113352"){
        $msg = "無法拔除原始管理員";
    }
    else if($_SESSION["uId"] == $id){
        $msg = "無法拔除自己";
    }else{
        $sql ="UPDATE user SET isAdmin = '0' WHERE uId='$id'";
        if(mysqli_query($link,$sql)){
            $msg= "成功拔除管理員權限 id=$id";
        }else{
            $msg= "拔除失敗，請稍後再試";
        }
    }
    echo json_encode(["msg"=>$msg])

?>