<?php
    session_start();
    if(isset($_SESSION["uId"])){
        require "../../asset/inc/dblink.inc";
        $uId = $_SESSION["uId"];
        $sql ="SELECT * FROM user WHERE uId = '$uId'";
        if(!mysqli_query($link,$sql)){
            echo"伺服器問題，請稍後再試";
            return 0;
        }else{
            $result = mysqli_fetch_assoc(mysqli_query($link,$sql));
            $uAcc = $result["Account"];
            $uMail = $result["mail"];
            $uDate = $result["createDate"];
            $uDept = $result["deptId"];
            $photoPath = $result["photoPath"];
        }
    }else{
        header("Location:./login.php");
    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../asset/css/normalize.css">
    <link rel="stylesheet" href="../../asset/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100..900&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.js" defer></script>
    <script src="../../asset/js/userinfo.js" defer></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <title>高大課程評價論壇-使用者資訊(<?php echo $uAcc;?>)</title>
</head>
<body class="blue-bg">
    <div class="header">
        <a href="../../index.php" id="left-header">
            <img src="../../asset/img/logo_forum.png" alt="" id="Logo-pic">
        </a>
        <div id="right-header">
            <form action="../article/show.php" method="get" id="search-area">
                <input type="text" name="QS" id="search-line">
                <input type="submit" value="搜尋" id="search-btn" class="sans">
            </form>
            <div id="user-area">
                <?php
                if(isset($_SESSION["uId"])){
                    echo "
                    <a href='../user/userinfo.php' class='info'>
                        <img src='$photoPath' alt=''>
                        <div id='user-info'>
                            <span class='sans' id='user-name'>$uAcc</span><br>
                            <span class='sans' id='user-mail'>$uMail</span>
                        </div>
                    </a>
                    ";
                }else{
                    echo '
                    <a href="../user/login.php" class="login">
                        <div id="login-area">
                            <span class="sans" id="login-text">註冊/登入</span><br>
                        </div>
                    </a>
                    ';
                }
                ?>
            </div>

        </div>

    </div>
    <div class="container" id="info-container">
        <form action="">
            <input type="hidden" id="uId" value="<?php echo $uId?>">
            <input type="hidden" id="uAcc" value="<?php echo $uAcc?>">
            <input type="hidden" id="uMail" value="<?php echo $uMail?>">
            <input type="hidden" id="uDate" value="<?php echo $uDate?>">
            <input type="hidden" id="uDept" value="<?php echo $uDept?>">
            <input type="hidden" id="uPhotoPath" value="<?php echo $photoPath?>">
        </form>
        <div class="info-area">
            <div id="info-area-L">
                <a href="#" id="baseInfoBtn" class="info-func-btn">基本資訊管理</a>
                <a href="#" id="changePhoto" class="info-func-btn">使用者頭像變更</a>
                <!-- <a href="#" id="allArticle" class="info-func-btn">文章總覽</a> -->
                <?php
                if($result["isAdmin"] == 1){
                    echo '<a href="#" id="admin-UserManage" class = "info-func-btn">管理使用者</a>';
                    // echo '<a href="#" id="admin-ArticleManage" class="info-func-btn">管理文章</a>';
                    echo '<a href="../chart/linechart.php" id="admin-Chart" class="info-func-btn">網站報表</a>';
                }
                ?>
                <a href="logout.php" id="logoutBtn" class="info-func-btn">登出</a>
            </div>
            <div id="info-area-R">
            </div>

        </div>
    </div>
</body>
</html>