<?php
    session_start();
    if($_SESSION["veri_situation"] == "newAccount" || $_SESSION["veri_situation"] == "changePassword"){
        require "../../asset/inc/dblink.inc";
        $uAcc = $_GET["uAcc"];
        $sql = "SELECT * FROM user WHERE Account = '$uAcc'";
        $result = mysqli_fetch_assoc(mysqli_query($link,$sql));
        $reciver = $result["mail"];
        $photoPath = $result["photoPath"];
        $_SESSION["uId"] = $result["uId"];
        $uId = $result["uId"];
        
    }else if($_SESSION["veri_situation"] == "forgotPassword"){
        $reciver = $_GET["mail"];
    }
    else if($_SESSION["veri_situation"] == "changeInfo"){
        require "../../asset/inc/dblink.inc";
        $uAcc = $_GET["uAcc"];
        $sql = "SELECT * FROM user WHERE Account = '$uAcc'";
        $result = mysqli_fetch_assoc(mysqli_query($link,$sql));
        $reciver = $_SESSION["newMail"];
        $photoPath = $result["photoPath"];
        $_SESSION["uId"] = $result["uId"];
        $uId = $result["uId"];
    }else{
        header("Location: ../default/");
    }


    if(isset($_COOKIE["sended"])){
    }else{
        //生成驗證碼
        $randStrData="123456789QWERTYUIOPASDFGHJKLZXCVBNM123456789";
        $length = strlen($randStrData);
        $varCode="";
        for( $i = 1 ; $i<=6 ; $i++){
            $varCode .= $randStrData[rand() % $length];
        }
        $_SESSION["varCode"] = $varCode;
    }
?>
<?php
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';


//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = false;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'a1113313@mail.nuk.edu.tw';                     //SMTP username
    $mail->Password   = 'zhgv dvhy xvpw uqur';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    $subject = "高大課程論壇信箱驗證信";

    //Recipients
    $mail->setFrom('a1113313@mail.nuk.edu.tw', '高大課程論壇管理員');      
    $mail->addAddress("$reciver");               //Name is optional
    //$mail->addReplyTo('info@example.com', 'Information');
    //$mail->addCC('cc@example.com');
    //$mail->addBCC('bcc@example.com');

    //Attachments
    //$mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

    //Content
    date_default_timezone_set('Asia/Taipei');
    $date = date("Y/m/d A h:i:s");
    $mail->CharSet = 'UTF-8';
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = $subject;
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    if(isset($_COOKIE["sended"])){
    }else{
    $mail->Body    = "你的論壇驗證碼為 : $varCode";
    $mail->send();
    $date = strtotime("+ 1 minutes",time());
    setcookie("sended",true,$date);
    }
}catch(e){

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <script src="../../asset/js/verify.js" defer></script>
    <link rel="stylesheet" href="../../asset/css/normalize.css">
    <link rel="stylesheet" href="../../asset/css/style.css">
    <title>高大課程評價論壇-驗證碼確認</title>
</head>
<body class="bg">
    <div class="header">
        <a href="../../index.php" id="left-header">
            <img src="../../asset/img/logo_forum.png" alt="" id="Logo-pic">
        </a>
        <div id="right-header">
            <form action="show.php" method="get" id="search-area">
                <input type="text" name="QS" id="search-line">
                <input type="submit" value="搜尋" id="search-btn" class="sans">
            </form>
            <div id="user-area">
                <?php
                if(isset($_SESSION["uId"])){
                    $uid=$_SESSION["uId"];
                    echo "
                    <a href='../user/userinfo.php?uId=$uid' class='info'>
                        <img src='$photoPath' alt=''>
                        <div id='user-info'>
                            <span class='sans' id='user-name'>$uAcc</span><br>
                            <span class='sans' id='user-mail'>$reciver</span>
                        </div>
                    </a>
                    ";
                }else{
                    echo '
                    <a href="../user/login.php" class="login">
                        <div id="login-area">
                            <span class="sans" id="login-text">註冊/登入</span><br>
                        </div>
                    </a>
                    ';
                }
                ?>
            </div>

        </div>

    </div>
    <div class="container">
        <div class="left-control"></div>
        <div class="login-area">
            <form action="verifyCheck.php" method="post" id="input-form">
                <img src="../../asset/img/logo_forum_black.png" alt="" class="input-img-login">
                <input type="hidden" id ="uMail" value="<?php echo $reciver?>">
                <input type="hidden" id ="situation" value="<?php echo $_SESSION["veri_situation"]; ?>">
                <input type="hidden" id ="uId" value="<?php echo $uId; ?>">
                <div class="sans word">已寄送驗證碼至信箱 : <?php echo $reciver?></div>
                <div class="input sans"><span>驗證碼-不分大小寫 (一分鐘後可重新寄送)</span><input type="text" name="var" id ="varCode"></div>
                <input type="submit" value="確認" class="input-btn sans" id="submit-btn">
            </form>
        </div>
    </div>
</body>
</html>