<?php
    require "../../asset/inc/dblink.inc";
    $id = $_GET["id"];

    $sql = "SELECT isAdmin From user WHERE uId='$id'";
    $result = mysqli_fetch_assoc(mysqli_query($link,$sql))["isAdmin"];

    if($result == 1){
        echo json_encode(["msg"=>"無法禁用管理員"]);
    }else{
        $sql ="UPDATE user SET isBaned = '1' WHERE uId='$id'";
        if(mysqli_query($link,$sql)){
            echo json_encode(["msg"=>"成功禁用使用者 id=$id"]);
        }else{
            echo json_encode(["msg"=>"禁用失敗，請稍後再試"]);
        }
    }
?>