<?php
    function getdeptName($link,$deptId) : string {
        $sql = "SELECT Name FROM depts WHERE Id='$deptId'";
        
        $result = mysqli_query($link,$sql);

        if(!$result){
            return "系所未定義";
        }else{
            $row = mysqli_fetch_assoc($result);
            return $row ? $row["Name"] : "系所未定義";
        }


    };

    function TureOrFalse($input) : string {
        if($input == 1){
            return "是";
        }else{
            return "否";
        }
        
    };
    require "../../asset/inc/dblink.inc";
    if(isset($_GET["QS"])){
        $dId;
        $qs = $_GET["QS"];
        //抓ID
        $sql = "SELECT Id FROM depts WHERE name LIKE '%$qs%'";
        $result = mysqli_query($link,$sql);

        $sql = "SELECT * 
                FROM user 
                WHERE uId LIKE '$qs' OR Account LIKE '%$qs%' OR mail LIKE '%$qs%'";

        if($result==null){
            $dId = "none";
        }else{
            while($rows = mysqli_fetch_assoc($result)){
                $dId = $rows["Id"];
                $sql.=" OR deptId = '$dId'";
            }
        }
    }else{
        $sql = "SELECT * FROM user";
    }

    $array = array();
    $result = mysqli_query($link,$sql);
    while($rows = mysqli_fetch_assoc($result)){
        $array[] = [$rows["uId"],
                    $rows["Account"],
                    $rows["mail"],
                    getdeptName($link,$rows["deptId"]) ,
                    TureOrFalse($rows["isAdmin"]),
                    TureOrFalse($rows["isBaned"])];
    }
    if($array == null){
        $array = [''];
    }
    echo json_encode($array);
?>