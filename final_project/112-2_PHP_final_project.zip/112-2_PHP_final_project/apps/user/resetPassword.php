<?php
    session_start();
    if($_SESSION["veri_situation"] != "forgotPassword"){
        header("Location: ../default/");
    }
    $uMail = $_GET["uMail"];
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.0.js"defer></script>
    <script src="../../asset/js/resetCheck.js" defer></script>
    <link rel="stylesheet" href="../../asset/css/normalize.css">
    <link rel="stylesheet" href="../../asset/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100..900&display=swap" rel="stylesheet">
    <title>高大課程評價論壇-重設密碼</title>
</head>
<body class="bg">
    <div class="header">
        <a href="../../index.php" id="left-header">
            <img src="../../asset/img/logo_forum.png" alt="" id="Logo-pic">
        </a>
        <div id="right-header">
            <form action="show.php" method="get" id="search-area">
                <input type="text" name="QS" id="search-line">
                <input type="submit" value="搜尋" id="search-btn" class="sans">
            </form>
            <div id="user-area">
                <?php
                if(isset($_SESSION["uId"])){
                    $uid=$_SESSION["uId"];
                    echo "
                    <a href='../user/userinfo.php?uId=$uid' class='info'>
                        <img src='$photoPath' alt=''>
                        <div id='user-info'>
                            <span class='sans' id='user-name'>$Account</span><br>
                            <span class='sans' id='user-mail'>$mail</span>
                        </div>
                    </a>
                    ";
                }else{
                    echo '
                    <a href="login.php" class="login">
                        <div id="login-area">
                            <span class="sans" id="login-text">註冊/登入</span><br>
                        </div>
                    </a>
                    ';
                }
                ?>
            </div>

        </div>

    </div>
    <div class="container">
        <div class="left-control"></div>
        <div class="login-area">
            <form action="DoReset.php" method="post">
                <img src="../../asset/img/logo_forum_black.png" alt="" class="input-img">
                <div class="input sans"><span>重設密碼 (<?php echo "$uMail";?>) </span></div>
                <input type="hidden" value="<?php echo $uMail?>" id ="uMail">
                <div class="input sans"><span>密碼 </span><input type="password" name="uPass" id="pass1" required></div>
                <div class="input sans"><span>再次輸入密碼 </span><input type="password" name="uPass" id="pass2" required></div>
                <input type="submit" value="確認更改" class="input-btn sans" id="submit-btn">
            </form>
        </div>
    </div>
</body>
</html>