<?php
    session_start();
    
    //取值
    $uAcc=$_POST["uAcc"];
    $uDept = $_POST["uDept"];
    $uMail=$_POST["uMail"];
    $uPass=$_POST["uPass"];
    $date = date("y-m-d");
    $passHash = hash('sha256',$uPass);
    $_SESSION["veri_situation"]="newAccount";
    //開始資料庫處理
    require "../../asset/inc/dblink.inc";
       
    $sql = "INSERT INTO user VALUES ('' , '$uAcc' , '$passHash' , '$uMail' , '$date' , '$uDept' ,'../../asset/img/user/default/default_user_img.png', '0' , '0','0')";
    mysqli_query($link,$sql);
    $_SESSION["veri_situation"] = "newAccount";
    $msg='';
    if($_SESSION["veri_situation"] == "newAccount"){
        $msg.="OK";
    }else{
        $msg.="unexpect error";
    }

    $data = [
        "msg"=>$msg ,
        "uAcc"=>$uAcc 
            ];

    echo json_encode($data);

    // $url = "verify.php?uAcc=".$uAcc;
    // header('Location: '.$url);
?>
