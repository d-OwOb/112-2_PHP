<?php
    session_start();
    $isPass = 1;
    $_SESSION["veri_situation"] = "changePassword";
    if($_SESSION["veri_situation"] != "changePassword"){
        $isPass =0;
    }
    echo json_encode(array("isPass"=>$isPass));

?>