<?php
session_start();
//身份檢查，若非會員或管理員則跳回show.php(管理員?)
if(!isset($_SESSION["uId"])){
    header("Location: show.php");
} 
?>
<meta charset="utf-8">

<?php
$articleId = $_POST["aId"];
$semester = $_POST["semester"];
$classtype = $_POST["dept"];
$classname = $_POST["classname"];
$teachername = $_POST["teachername"];
$rating = $_POST["rating"];
$title = $_POST["title"];
$articlecontent = $_POST["articlecontent"];

require "../../asset/inc/dblink.inc";
$sql = "UPDATE article SET Title='$title', Semester='$semester', ClassName='$classname',
        ClassType='$classtype', Teacher='$teachername', Rating='$rating', ArticleContent='$articlecontent'
        WHERE ArticleId = '$articleId'";


if(mysqli_query($link, $sql)) {
    echo "編輯成功<br>";
} else {
    echo "編輯失敗<br>";
}

header("Location:show.php");

?>