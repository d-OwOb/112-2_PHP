<?php
    session_start();    
    require "../../asset/inc/dblink.inc";
    $isLogin = false;
    //檢查登入
    if(isset($_SESSION["uId"])){
        $isLogin = true;
        $uId = $_SESSION["uId"];
        $sql = "SELECT * FROM user WHERE uId = '$uId'";
        $result = mysqli_fetch_assoc(mysqli_query($link,$sql));
        $Account = $result["Account"];
        $mail = $result["mail"];
        $isBaned = $result["isBaned"];
        $uPhotoPath = $result["photoPath"];
    }else{
        header("Location:show.php");
    }
?>
<meta charset="utf-8">
<?php 
    $articleId = $_GET["ArticleId"]; 
    require "../../asset/inc/dblink.inc";
    $sql = "SELECT * FROM article WHERE ArticleId = '$articleId'";

    if($result = mysqli_query($link, $sql)) {
        $rows = mysqli_fetch_assoc($result);
        $semester = $rows["Semester"];
        $classtype = $rows["ClassType"];
        $classname = $rows["ClassName"];
        $teachername = $rows["Teacher"];
        $rating = $rows["Rating"];
        $title = $rows["Title"];
        $articlecontent = $rows["ArticleContent"];
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../asset/css/normalize.css">
    <link rel="stylesheet" href="../../asset/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100..900&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.js" defer></script>
    <!-- <script src="../../asset/js/AddArticle.js" defer></script> -->
    <title>高大課程評價論壇-編輯文章-<?php echo $title?></title>
</head>
<body class="index-bg">
    <div class="header">
        <a href="../default/index.php" id="left-header">
            <img src="../../asset/img/logo_forum.png" alt="" id="Logo-pic">
        </a>
        <div id="right-header">
            <form action="../article/show.php" method="get" id="search-area">
                <input type="text" name="QS" id="search-line">
                <input type="submit" value="搜尋" id="search-btn" class="sans">
            </form>
            <div id="user-area">
                <?php
                if(isset($_SESSION["uId"])){
                    $uid=$_SESSION["uId"];
                    echo "
                    <a href='../user/userinfo.php?uId=$uid' class='info'>
                        <img src='$uPhotoPath' alt=''>
                        <div id='user-info'>
                            <span class='sans' id='user-name'>$Account</span><br>
                            <span class='sans' id='user-mail'>$mail</span>
                        </div>
                    </a>
                    ";
                }else{
                    echo '
                    <a href="../user/login.php" class="login">
                        <div id="login-area">
                            <span class="sans" id="login-text">註冊/登入</span><br>
                        </div>
                    </a>
                    ';
                }
                ?>
            </div>

        </div>

    </div>
    <div class="index-container">
            <div class="main-page">
                <form class="arti-form" action="UpdateDB.php" method="post">
                    <input id="isBaned" type="hidden" value=<?php echo "$isBaned"?>>
                    <div class="form-row sans">
                        <span>請選擇開課學期:</span>
                        <select class="seletion" name="semester" id="semester">
                        <?php 
                            echo '<option value="'.$semester.'">'.$semester.'</option>';
                            $semesterList = array("未選擇", "111-1", "111-2", "112-1", "112-2");
                            foreach($semesterList as $element) {
                                if($element != $semester) {
                                    echo '<option value="'.$element.'">'.$element.'</option>';
                                } else {
                                    continue;
                                }
                            }
                        ?> 
                        </select>
                    </div>
                    <div class="form-row sans">
                        <span>請選擇開課系所:</span>
                        <select class="seletion" name="dept" id="dept">
                        <?php 
                            $deptList1 = array("未選擇", "共同必修", "核心通識", "通識人文科學", "通識自然科學", "通識社會科學", "全民國防教育"); 
                            
                            require "../../asset/inc/dblink.inc";
                            $sql = "SELECT Name FROM depts";
                            $result = mysqli_query($link, $sql);
                            $deptList2=[];
                            while($row = mysqli_fetch_assoc($result)) {
                                array_push($deptList2, $row["Name"]);
                            }
                        
                            $deptList = array_merge($deptList1, $deptList2);
                            array_push($deptList, "創新學院不分系");
                            
                            echo '<option value="'.$classtype.'">'.$classtype.'</option>';
                            foreach($deptList as $element) {
                                if($element != $classtype) {
                                    echo '<option value="'.$element.'">'.$element.'</option>';
                                } else {
                                    continue;
                                }
                            }
                        ?> 
                        </select>
                    </div>
                    <input type="hidden" name="aId" value="<?php echo $articleId?>">
                    <div class="form-row sans"><span>請輸入課程名稱:</span><input class="form-input-area" type="text" name="classname" value="<?php echo $classname ?>" required></div>
                    <div class="form-row sans"><span>請輸入教師姓名:</span><input class="form-input-area" type="text" name="teachername" value="<?php echo $teachername ?>" required></div>
                    <div class="form-row sans"><span>請輸入課程評分:</span><input class="form-input-area" type="text" name="rating" value="<?php echo $rating ?>" required></div>
                    <div class="form-row sans"><span>請輸入評論標題:</span><input class="form-input-area" type="text" name="title" value="<?php echo $title ?>" required></div>
                    <div class="form-row-content form-row sans"><span>請輸入課程評論:</span><textarea class="form-input-area"  id="content" name="articlecontent" rows="10" cols="30" required><?php echo $articlecontent ?></textarea></div>
                    <input id="submit-btn" type="submit" value="送出資料">
                </form>
            </div>
    </div>
    
</body>
</html>