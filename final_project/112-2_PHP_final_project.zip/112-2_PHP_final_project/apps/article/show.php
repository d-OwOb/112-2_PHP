<?php
    session_start();    
    require "../../asset/inc/dblink.inc";
    $isLogin = false;
    //檢查登入
    if(isset($_SESSION["uId"])){
        $isLogin = true;
        $uId = $_SESSION["uId"];
        $sql = "SELECT * FROM user WHERE uId = '$uId'";
        $result = mysqli_fetch_assoc(mysqli_query($link,$sql));
        $Account = $result["Account"];
        $mail = $result["mail"];
        $uPhotoPath = $result["photoPath"];
    }
    $qs="";
    $sql = "SELECT *
                FROM user JOIN article ON user.uId = article.uId 
            ";

    //檢查搜尋字串        
    $sql_where='';
    if(isset($_GET["QS"])) {
        $qs = $_GET["QS"];
        $sql_where="
            WHERE article.Title LIKE '%$qs%' 
            OR article.Semester LIKE '%$qs%' 
            OR article.ClassName LIKE '%$qs%' 
            OR article.ClassType LIKE '%$qs%' 
            OR article.Teacher LIKE '%$qs%' 
            OR article.Rating LIKE '%$qs%' 
            OR article.CreateDate LIKE '%$qs%' 
            OR article.uId LIKE '%$qs%' 
            ORDER BY article.articleId DESC
        ";
        $sql.=$sql_where;
    }
    
    
    //檢查頁數
    $page;
    if(!isset($_GET["page"])){
        $page=1;
    }else{
        $page=$_GET["page"];
    }


    $arti_per_page = 5 ;
    $skip = (($page-1)*$arti_per_page);
    $sql.="LIMIT $skip,$arti_per_page";
    $result = mysqli_query($link, $sql);

    //取得最大頁數
    $sql='  SELECT count(*) as count 
            FROM article
    ';
    $sql.=$sql_where;
    $max_page = mysqli_fetch_assoc(mysqli_query($link,$sql))["count"];
    $max_page = ceil($max_page/5);
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../asset/css/normalize.css">
    <link rel="stylesheet" href="../../asset/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100..900&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.js" defer></script>
    <script src="../../asset/js/show.js" defer></script>
    <title>高大課程評價論壇-文章列表</title>
</head>
<body class="index-bg">
    <div class="header">
        <a href="../default/index.php" id="left-header">
            <img src="../../asset/img/logo_forum.png" alt="" id="Logo-pic">
        </a>
        <div id="right-header">
            <form action="../article/show.php" method="get" id="search-area">
                <input type="text" name="QS" id="search-line" value="<?php echo $qs?>">
                <input type="submit" value="搜尋" id="search-btn" class="sans">
            </form>
            <div id="user-area">
                <?php
                if(isset($_SESSION["uId"])){
                    $uid=$_SESSION["uId"];
                    echo "
                    <a href='../user/userinfo.php?uId=$uid' class='info'>
                        <img src='$uPhotoPath' alt=''>
                        <div id='user-info'>
                            <span class='sans' id='user-name'>$Account</span><br>
                            <span class='sans' id='user-mail'>$mail</span>
                        </div>
                    </a>
                    ";
                }else{
                    echo '
                    <a href="../user/login.php" class="login">
                        <div id="login-area">
                            <span class="sans" id="login-text">註冊/登入</span><br>
                        </div>
                    </a>
                    ';
                }
                ?>
            </div>

        </div>

    </div>
    <div class="index-container">
            <div class="main-page arti-main-page">
                <div class="arti-func-div">
                    <Button class="sans" id="add-arti-btn">新增文章</Button>
                </div>
                <div class="arti-meta-div sans">
                    <span class="artimeta-poster">發文者</span>
                    <span class="artimeta-title">標題與內文</span>
                    <span class="artimeta-rate">評分</span>
                    <span class="artimeta-date">發布日期</span>
                    <span class="artimeta-teacher">系所、教師、課名</span>
                </div>
                <div class="arti-content-div">
                <?php
                    while($rows = mysqli_fetch_assoc($result)) {
                        //取值
                        $Acc = $rows["Account"];
                        $articleId = $rows["ArticleId"];
                        $articleTitle = $rows["Title"];
                        $articleContent = $rows["ArticleContent"];
                        $rate = $rows["Rating"];
                        $teacher = $rows["Teacher"];
                        $className = $rows["ClassName"];
                        $date = $rows["CreateDate"];
                        $photoPath = $rows["photoPath"];
                        $classType = $rows["ClassType"];
                        //內文預覽處理
                        $maxLength = 50;
                        $showContent='';
                        if(strlen($articleContent) >= $maxLength){
                            $showContent = mb_substr($articleContent,0,$maxLength,"UTF-8");
                           
                        $showContent.='...';
                        }else{
                            $showContent = $articleContent;
                        }



                        echo"
                    <a href='ViewArticle.php?ArticleId=$articleId' class='arti-div'>
                        <div class='arti-img'><img src='$photoPath' alt=''><span class='sans img-acc'>$Acc</span></div>
                        <div class='arti-info'>
                            <div class='arti-title sans'>$articleTitle</div>
                            <div class='arti-content sans'>$showContent</div>
                        </div>                        
                        <div class='arti-rate sans'>$rate</div>
                        <div class='arti-date sans'>$date</div>
                        <div class='arti-teacher-name sans'><span>$classType</span><span>$teacher</span>$className<span></span></div>
                    </a>
                        ";
                    }
                ?>
                </div>
                <div class="arti-pagectrl-div">
                    <?php
                        $mid_page;
                        if($page>3 && $page<$max_page-2){
                            $mid_page=$page;
                        }else if($page <= 3 || $max_page==4){
                            $mid_page = 3;
                        }else{
                                $mid_page = $max_page-2;
                        }
                        if($page !=1){
                            $back = $page-1;
                            $back .= "&QS=$qs";
                            echo "<a href='show.php?page=$back' class='page-btn sans'><<</a>";
                        }else{
                            echo "<span class='page-btn sans hidden-btn'><<</span>";
                        }
                        for($i=-2 ; $i<=2 ;$i++){
                            $output = $mid_page+$i;
                            if($output>$max_page){
                                break;
                            }
                            if($output == $page){
                                echo "<span class='page-btn sans' id='pagenow'>$output</span>";
                            }else{
                                $output_herf = $output."&QS=$qs";
                                echo "<a href='show.php?page=$output_herf' class='page-btn sans'>$output</a>";
                            }
                        }
                        if($page != $max_page){
                            $forward = $page+1;
                            $forward .= "&QS=$qs";
                            echo "<a href='show.php?page=$forward' class='page-btn sans'>>></a>";
                        }else{
                            echo "<span class='page-btn sans hidden-btn'>>></span>";
                        }
                    ?>
                </div>
            
            </div>
        </div>
    </div>

</body>
</html>