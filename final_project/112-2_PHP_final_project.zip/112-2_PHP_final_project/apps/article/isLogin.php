<?php
    session_start();
    if(isset($_SESSION["uId"])){
        echo json_encode(true);
    }else{
        echo json_encode(false);
    }
?>