<?php
    session_start();
    //身份檢查，若非會員或管理員則跳回show.php(管理員?)
    if(!isset($_SESSION["uId"])){
        header("Location: show.php");
    }

    $articleId = $_GET["ArticleId"]; 
    require "../../asset/inc/dblink.inc";
    $sql = "DELETE FROM article WHERE ArticleId = '$articleId'";
    
    if(mysqli_query($link, $sql)){
        echo "刪除成功<br>";
    }

    header("Location:show.php");
?>