<?php
    session_start();    
    require "../../asset/inc/dblink.inc";
    $isLogin = false;
    //檢查登入
    if(isset($_SESSION["uId"])){
        $isLogin = true;
        $uId = $_SESSION["uId"];
        // $sql = "SELECT * FROM user WHERE uId = '$uId'";
        // $result = mysqli_fetch_assoc(mysqli_query($link,$sql));
        // $Account = $result["Account"];
        // $mail = $result["mail"];
        // $isBaned = $result["isBaned"];
        // $uPhotoPath = $result["photoPath"];
    }else{
        header("Location:show.php");
    }
?>
<?php
    $semester = $_POST["semester"];
    $dept = $_POST["dept"];
    $classname = $_POST["classname"];
    $teachername = $_POST["teachername"];
    $rating = $_POST["rating"];
    $title = $_POST["title"];
    $articlecontent = $_POST["articlecontent"];
    // date_default_timezone_set("Asia/Taipei");
    $date = date("Y-m-d");

    require "../../asset/inc/dblink.inc";
    $sql = "INSERT INTO article(Title, Semester, ClassName, ClassType, Teacher, Rating, ArticleContent, CreateDate, uId)
            VALUES('$title', '$semester', '$classname', '$dept', '$teachername', '$rating', '$articlecontent', '$date', '$uId')";
    $msg='';
    if(mysqli_query($link, $sql)) {
            $msg.="新增成功";
        } else {
            $msg.="fail in php";
    }
    $data=array(
        "msg" => $msg
    );

    
    echo json_encode($data);
?>