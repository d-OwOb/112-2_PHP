<?php
ob_start();
session_start();
//身份檢查，若非管理員則跳回show.php(管理員?)
if(!isset($_SESSION["uId"])){
  header("Location: ../user/userinfo.php");
}
?>

<meta charset="utf-8">

<?php 
require_once('../TCPDF/tcpdf.php');

require "../../asset/inc/dblink.inc";
$sql = "SELECT * FROM article JOIN user ON article.uId = user.uId ORDER BY article.CreateDate DESC";
$result = mysqli_query($link, $sql);

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

$pdf->SetFont('msungstdlight', '', 10);
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

$count = 1;
while ($rows = mysqli_fetch_assoc($result)) {

    $html  = '<table border="1" style="text-align:center;"><thead>';
    $html .= '<tr><td colspan="8" style="font-size:24px">'.$count.'</td></tr>';
    $html .= '<tr><td>帳號名稱</td>';
    $html .= '<td>文章標題</td>';
    $html .= '<td>發文日期</td>';
    $html .= '<td>開課學期</td>';
    $html .= '<td>課程名稱</td>';
    $html .= '<td>開課系所</td>';
    $html .= '<td>課程教師</td>';
    $html .= '<td>評分</td>';
    $html .= '</tr></thead><tbody>';
    $html .=  "<tr><td>".$rows["Account"]."</td>";
    $html .=  "<td>".$rows["Title"]."</td>";
    $html .=  "<td>".$rows["CreateDate"]."</td>";
    $html .=  "<td>".$rows["Semester"]."</td>";
    $html .=  "<td>".$rows["ClassName"]."</td>";
    $html .=  "<td>".$rows["ClassType"]."</td>";
    $html .=  "<td>".$rows["Teacher"]."</td>";
    $html .=  "<td>".$rows["Rating"]."</td></tr>";
    $html .=  '<tr><td>評論</td><td colspan="7" style="text-align:left;">'.nl2br($rows["ArticleContent"]).'</td></tr>';
    $count++;
    $html.="</tbody></table><br><br>";
    $pdf->AddPage();
    $pdf->writeHTML($html);
}


// set font



// output the HTML content


//file send to file address
date_default_timezone_set("Asia/Taipei");
$datetime = date("Ymd_His");
$path = "/".$datetime.".pdf";

//Close and output PDF document
ob_end_clean();
$pdf->Output(__DIR__ .$path, 'D');

//$pdf->Output($No."-tableinfo.pdf", 'D');
ob_end_flush();
?>