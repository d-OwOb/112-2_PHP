<?php 
session_start();
//身份檢查，若非會員或管理員則跳回show.php(管理員?)
if(!isset($_SESSION["uId"])){
  header("Location: ../user/userinfo.php");
}
?>

<html>
  <head>
    <meta charset="utf-8">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
            ['日期', '每日總發文數']
            <?php
            require "../../asset/inc/dblink.inc";
            $sql = "SELECT CreateDate, COUNT(CreateDate) AS NumOfDate FROM article GROUP BY CreateDate";
            $result = mysqli_query($link, $sql);
            while($rows = mysqli_fetch_assoc($result)){
              $date = $rows["CreateDate"];
              $numOfDate = $rows["NumOfDate"];
              echo ",['$date', $numOfDate]";
            } 
          ?>
        ]);

        var options = {
          title: '高大課程評價論壇-每日發文數',
          curveType: 'none',
          legend: { position: 'top' },
          vAxis: {title: '每日發文數' , minValue: 0, format: "#"},
          hAxis: {title: '日期'},
          pointSize : 5
        }
        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="curve_chart" style="width: 900px; height: 500px"></div>
  </body>
</html>