<?php 
session_start();
//身份檢查，若非管理員則跳回show.php(管理員?)
if(!isset($_SESSION["uId"])){
  header("Location: ../user/userinfo.php");
}
?>
<meta charset="utf-8">

<?php
date_default_timezone_set("Asia/Taipei");
$datetime = date("Ymd_His");

header("Pragma: public");
header("Expires: 0");
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Content-type: application/vnd.ms-excel');
header('Content-Disposition: inline; filename="'.$datetime.'.xls";');
header('Content-Transfer-Encoding: binary');

require "../../asset/inc/dblink.inc";
$sql = "SELECT * FROM article JOIN user ON article.uId = user.uId ORDER BY article.CreateDate DESC" ;
$result = mysqli_query($link, $sql);

echo "<table border='1'>";
echo "<tr><td>帳號名稱</td>";
echo "<td>文章標題</td>";
echo "<td>發文日期</td>";
echo "<td>開課學期</td>";
echo "<td>課程名稱</td>";
echo "<td>開課系所</td>";
echo "<td>課程教師</td>";
echo "<td>評分</td>";
echo "<td>評論</td></tr>";

while ($rows = mysqli_fetch_assoc($result)) {
    echo "<tr><td>".$rows["Account"]."</td>";
    echo "<td>".$rows["Title"]."</td>";
    echo "<td>".$rows["CreateDate"]."</td>";
    echo "<td>".$rows["Semester"]."</td>";
    echo "<td>".$rows["ClassName"]."</td>";
    echo "<td>".$rows["ClassType"]."</td>";
    echo "<td>".$rows["Teacher"]."</td>";
    echo "<td>".$rows["Rating"]."</td>";
    echo "<td>".nl2br($rows["ArticleContent"])."</td></tr>";
}
echo "</table>";
?>