<?php
session_start();
require "../../asset/inc/dblink.inc";
$isLogin = false;
if(isset($_SESSION["uId"])){
    $isLogin = true;
    $uId = $_SESSION["uId"];
    $sql = "SELECT * FROM user WHERE uId = '$uId'";
    $result = mysqli_fetch_assoc(mysqli_query($link,$sql));
    $Account = $result["Account"];
    $mail = $result["mail"];
    $photoPath = $result["photoPath"];
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../asset/css/normalize.css">
    <link rel="stylesheet" href="../../asset/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@100..900&display=swap" rel="stylesheet">
    <title>高大課程評價論壇-首頁</title>
</head>
<body class="index-bg">
    <div class="header">
        <a href="index.php" id="left-header">
            <img src="../../asset/img/logo_forum.png" alt="" id="Logo-pic">
        </a>
        <div id="right-header">
            <form action="../article/show.php" method="get" id="search-area">
                <input type="text" name="QS" id="search-line">
                <input type="submit" value="搜尋" id="search-btn" class="sans">
            </form>
            <div id="user-area">
                <?php
                if(isset($_SESSION["uId"])){
                    echo "
                    <a href='../user/userinfo.php' class='info'>
                        <img src='$photoPath' alt=''>
                        <div id='user-info'>
                            <span class='sans' id='user-name'>$Account</span><br>
                            <span class='sans' id='user-mail'>$mail</span>
                        </div>
                    </a>
                    ";
                }else{
                    echo '
                    <a href="../user/login.php" class="login">
                        <div id="login-area">
                            <span class="sans" id="login-text">註冊/登入</span><br>
                        </div>
                    </a>
                    ';
                }
                ?>
            </div>

        </div>

    </div>
    <div class="index-container">
            <div class="main-page">
                <div class="left-in">
                    <a href="../article/show.php" class="to-article">
                        <img src="../../asset/img/note-paper-01.png" alt="" class="article-img">
                        <span class="arti-text sans">前往評價列表</span>
                    </a>
                </div>
                <div class="mid-line"></div>
                <div class="right-in">
                    <a href="<?php $isLogin ? print ("../user/userinfo.php") : print("../user/login.php") ;?>" class="to-article">
                            <img src="../../asset/img/user-img.png" alt="" class="touser-img">
                            <span class="arti-text sans"><?php $isLogin ? print ("前往管理頁面") : print("前往登入頁面") ;?></span>
                        </a>
                </div>
        </div>
    </div>

</body>
</html>