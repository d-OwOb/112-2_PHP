var uId = document.getElementById("uId").value;
var uAcc = document.getElementById("uAcc").value;
var uMail = document.getElementById("uMail").value;
var uDate = document.getElementById("uDate").value;
var uDept = document.getElementById("uDept").value;
var uPhotoPath = document.getElementById("uPhotoPath").value;
var div = document.getElementById("info-area-R");

ini();
/////////////////////////////////////////////////////////////////////換頭像
$("#changePhoto").click(function (e) { 
    e.preventDefault();
    $(div).empty();
    var html = "";
    html+=`<div id="photo-text" class="sans">頭像更換</div>`;
    html+=`<img src="${uPhotoPath}" id="info-photo">`;
    html+=`
            <form id="photo-form" action = "doUploadPhoto.php" method ="POST" enctype="multipart/form-data">
                <input type="file" name = "newPhoto" accept=".png , .jpg , .jpeg" class = "sans" id="file-select">
                <input type = "submit" value="上傳頭像" id="photo-submit" class="sans">
            </form>`;
    div.innerHTML = html;
});
//////////////////////////////////////////////////////////////基本資訊
$("#baseInfoBtn").click(function (e) { 
    e.preventDefault();
    ini();
    
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////管理使用者////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
$("#admin-UserManage").click(async function (e) { 
    await CreateTable(e);

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////報表////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
google.charts.load('current', {'packages':['corechart']});
// google.charts.setOnLoadCallback(drawChart);

$("#admin-Chart").click(async function (e) { 
    e.preventDefault();
    $(div).empty();
    var html=`
        <div id='curve_chart'></div>
        <div class="chart_func">
        <a class="data-func-btn" href="../chart/arti_pdf.php" target="_blank">下載全文章PDF</a>
        <a class="data-func-btn" href="../chart/excel.php" target="_blank">下載全文章excel</a>
        </div>
    `;
    div.innerHTML = html;
    await $.get("GET_CHART_DATA.php", '',
    function (data) {
        drawChart(data);
    },
    "json"
    );
});

async function drawChart(data) {
    data_merge=[['日期', '每日總發文數']];
    for(var i =0 ;i<data.length;i++){
        data_merge.push([data[i][0],parseInt(data[i][1])]);
    }
    var chart_data = google.visualization.arrayToDataTable(
        data_merge
    );
    var options = {
      title: '高大課程評價論壇-每日發文數',
      curveType: 'none',
      legend: { position: 'top' },
      vAxis: {title: '每日發文數' , minValue: 0, format: "#"},
      hAxis: {title: '日期'},
      pointSize : 5
    }
    var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));
    chart.draw(chart_data, options);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////生成使用者表格 & 操作/////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
async function CreateTable(e) {
    e.preventDefault();
    var qs;
    try{
         qs = document.getElementById("userQS").value;
    }catch{
         qs = '';
    }
    $(div).empty();
    var html="";
    html+=` <div id = "table-container">
                <div>
                <span>搜尋使用者 </span>
                <input type = "text" id = "userQS" value="${qs}">
                <input type="submit" id="userQSBtn" value="查詢">
                </div>
                <div class="scroll-div">
                <table id="info-table">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">帳號</th>
                            <th scope="col">信箱</th>
                            <th scope="col">系所</th>
                            <th scope="col">管理員</th>
                            <th scope="col">被禁用</th>
                            <th scope="col">操作</th>
                        </tr>
                    </thead>
                    <tbody>
    `;
    if(qs != ''){
        data={"QS":qs};
    }else{
        data="";
    }

    await $.get("GET_USERS.php", data,
    function (data) {
        if(data == ""){
            html+=`<div id="noResult" class="sans">未發現結果</div>`;
        }
        else{
            for(var i =0 ; i<data.length ; i++ ){
                //管理員狀態判定
                var admin_opration;
                if(data[i][4] =="否"){
                    admin_opration = `<button class="asignAdmin" data-btnid="${data[i][0]}">指定管理員</button>`;
                }else{
                    admin_opration = `<button class="delAdmin" data-btnid="${data[i][0]}">拔除管理員</button>`;
                }
                //禁用狀態判定
                var ban_op;
                if(data[i][5] =="否"){
                    ban_op = `<button type="button" class="banUser" data-btnid="${data[i][0]}">禁用</button>`;
                }else{
                    ban_op = `<button type="button" class="unbanUser" data-btnid="${data[i][0]}">解禁</button>`;
                }
                /////////////////
                html+=`
                        <tr>                
                            <th scope="col">${data[i][0]}</th>
                            <td>${data[i][1]}</th>
                            <td>${data[i][2]}</th>
                            <td>${data[i][3]}</th>
                            <td>${data[i][4]}</th>
                            <td>${data[i][5]}</th>
                            <td>
                                <button type="button" class="delete-btn" data-btnid="${data[i][0]}">刪除</button>
                                ${ban_op}
                                ${admin_opration}
                        </tr>
                `;
            }
        }
    },
    "json"
);
    html+=`
            </tbody></table></div></div>
    `;   

    div.innerHTML = html;
    //查詢
    $("#userQSBtn").click(function (e) { 
        CreateTable(e);
    });
    /////刪除使用者
    $("#info-table").click(async function (e) { 
        var target = e.target;
        if(target.tagName =="BUTTON" && target.className=="delete-btn"){
            var id = target.dataset.btnid;
            var data = {"delId" : id}
            if(confirm(`確定刪除使用者${id}嗎`)){
                await $.get("delUser.php", data,
                    function (data) {
                        alert(data.msg);
                        CreateTable(e);
                    },
                    "json"
                );
            }

        }
    });
    /////指定為管理員
    $("#info-table").click(async function (e) { 
        var target = e.target;
        if(target.tagName =="BUTTON" && target.className=="asignAdmin"){
            var data = {"id" : target.dataset.btnid}
            $.get("asignAdmin.php", data,
                function (data) {
                    alert(data.msg);
                    CreateTable(e);
                },
                "json"
            );
        }
    });    
    /////拔除管理員
    $("#info-table").click(async function (e) { 
        var target = e.target;
        if(target.tagName =="BUTTON" && target.className=="delAdmin"){
            var data = {"id" : target.dataset.btnid}
            $.get("delAdmin.php", data,
                function (data) {
                    alert(data.msg);
                    CreateTable(e);
                },
                "json"
            );
        }
    });    
    /////禁用
    $("#info-table").click(async function (e) { 
        var target = e.target;
        if(target.tagName =="BUTTON" && target.className=="banUser"){
            var data = {"id" : target.dataset.btnid}
            $.get("banUser.php", data,
                function (data) {
                    alert(data.msg);
                    CreateTable(e);
                },
                "json"
            );
        }
    }); 
    /////解禁
    $("#info-table").click(async function (e) { 
        var target = e.target;
        if(target.tagName =="BUTTON" && target.className=="unbanUser"){
            var data = {"id" : target.dataset.btnid}
            $.get("unbanUser.php", data,
                function (data) {
                    alert(data.msg);
                    CreateTable(e);
                },
                "json"
            );
        }
    }); 
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////  ini()  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

async function ini() {
    $(div).empty();
    var html = "";
    var depts;  
    await $.getJSON("getDepts.php","",
        function (data) {
            depts = data;
        }
    );
    html+=`<div id="infoManage-text" class="sans">個人資料管理</div>`;
    html+=`
        <div class = "infoManage-div"><span class=" sans info-markText">帳號</span><span class="info-data-whiteBG">${uAcc}</span></div>
        <div class = "infoManage-div"><span class=" sans info-markText">密碼</span><a href="#" id="info-data-CP">變更密碼</a></div>
        <div class = "infoManage-div"><span class=" sans info-markText">信箱</span><input type="text" value="${uMail}" id = "mail"></div>
        <div class = "infoManage-div"><span class=" sans info-markText">創建日期</span><span class="info-data-whiteBG">${uDate}</span></div>
        <div class = "infoManage-div"><span class=" sans info-markText">系所</span><select id="dept">`;

    for(var i =0 ; i<depts.length ; i++ ){
        html+=`<option value="${depts[i][0]}" `;
        if(depts[i][0] == uDept){
            html+="SELECTED";
        }
        html+=`>${depts[i][1]}</option>`;
    }
    html+=`</select></div>
        <a href ="#" class ="sans" id="infoManage-submit">確認修改</div>
    `;
    div.innerHTML = html;

    $("#info-data-CP").click(async function (e) { 
        e.preventDefault();
        await $.get("CP_GETSESSION.php", "",
            function (data) {
                if(data.isPass != 1){
                    alert("出現錯誤，請稍後再試");
                }else{
                    location.href = `./verify.php?uAcc=${uAcc}`;
                }
            },
            "json"
        );
    });
    $("#infoManage-submit").click(async function (e) { 
        e.preventDefault();
        var mail = document.getElementById("mail").value;
        var dept = document.getElementById("dept").value;
        var data ={
            "newMail" : mail , 
            "newDept" : dept
        };
        await $.post("CI_GETSESSION.php", data,
            function (data) {
                if(data.isPass != 1){
                    alert("出現錯誤，請稍後再試");
                }else{
                    location.href = `./verify.php?uAcc=${uAcc}`;
                }
            },
            "json"
        );
    });
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////