var btn = document.getElementById("submit-btn");

$(btn).click(async function (e) { 
    e.preventDefault();
    
    var uAcc = document.getElementById("uAcc").value;
    var uPass = document.getElementById("uPass").value;
    var data ={
        "uAcc" : uAcc,
        "uPass" : uPass
    }
    await $.post("loginCheck.php", data,
        function (data) {
            if(data.isPass != 1){
                alert(data.msg);
            }else{
                var loginData = {'uAcc': uAcc}
                $.post("DoLogin.php", loginData,
                    function (data) {
                        alert("登入成功");
                        location.href = '../default/index.php';
                    },
                    "json"
                );
            }
        },
        "json"
    );
});