option();

async function option() {
    var html="<option value='none'>未選擇</option>";
    var depts;  
    await $.getJSON("getDepts.php","",
        function (data) {
            depts = data;
        }
    );
    for(var i =0 ; i<depts.length ; i++ ){
        html+=`<option value=${depts[i][0]}>${depts[i][1]}</option>`;
    }
    var div = document.getElementById("dept-selection");
    div.innerHTML = html;
}



