var submit_btn = document.getElementById("submit-btn");

submit_btn.addEventListener("click", (e)=>{check(e)});

async function check(e) {
    var uAcc = document.getElementById("uAcc").value;
    var uDept = document.getElementById("dept-selection").value;
    var uMail = document.getElementById("uMail").value;
    var pass1 = document.getElementById("pass1").value;
    var pass2 = document.getElementById("pass2").value;

    e.preventDefault();
    var error = 0;
    var errormsg="";
    var uPass;

    if(! new RegExp('[a-z0-9A-Z]{8,}').test(uAcc)){
        errormsg += '帳號須為8位以上英數字\n';
        error++;
    }

    if(uDept == 'none'){
        errormsg += '未選擇系所\n';
        error++;
    }

    if(! new RegExp('[a-z0-9A-Z]+\@{1}[a-z0-9]+[.]{1}[a-z]+').test(uMail)){
        errormsg+="信箱不合法\n"
        error++;
    }

    if(pass1!= pass2){
        errormsg+="密碼不一致\n";
        error++;
    }else{
        uPass = pass1;

        if(uPass.length < 8){
            errormsg+="密碼不足8位數\n";
            error++;
        }
    }

    var data = {"uAcc":uAcc , "uMail":uMail};
    await $.get("AccMailCheck.php", data,
            function  (data) {
                if(data.isPass == 0){
                    errormsg += data.msg;
                    error++;
                }
            },
            "json"
        );

    if(error!=0){
        alert(errormsg);
    }else{
        var data={
            "uAcc" : uAcc , 
            "uDept" : uDept , 
            "uMail" : uMail , 
            "uPass" : uPass
        };
        await $.post("DoReg.php", data,
            function (data) {
                if(data.msg == "OK"){
                    location.href = `verify.php?uAcc=${data.uAcc}`;
                }else{
                    alert("error 500 伺服器錯誤");
                }
            },
            "json"
        ).fail(function () {
            alert("AJAX ERROR");
        });
        // var url = `./DoReg.php?uAcc=${uAcc}&uDept=${uDept}&uMail=${uMail}&uPass=${uPass}`;
        // location.href = url;
    }

}