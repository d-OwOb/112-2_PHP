
var btn = document.getElementById("submit-btn");
$(btn).click(async function (e) { 
    e.preventDefault();
    
    var uMail = document.getElementById("uMail").value;
    var data ={
        "uMail" : uMail
    }
    await $.post("forgotPassCheckMail.php", data,
        function (data) {
            if(data.isPass != 1){
                alert(data.msg);
            }else{
                var url = `verify.php?mail=${uMail}`;
                location.href = url;
            }
        },
        "json"
    );
});