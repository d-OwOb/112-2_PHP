
$("#add-arti-btn").click(async function (e) { 
    e.preventDefault();
    await $.get("isLogin.php", '',
        function (data) {
            console.log(data)
            if(data){
                location.href = "AddArticle.php";
            }else{
                alert("尚未登入!!!");
                location.href="../user/login.php";
            }
        },
        "json"
    );
});

