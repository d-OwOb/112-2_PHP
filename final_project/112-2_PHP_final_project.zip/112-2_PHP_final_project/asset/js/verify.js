var btn = document.getElementById("submit-btn");
var mail = document.getElementById("uMail").value;
var uId = document.getElementById("uId").value;
var situation = document.getElementById("situation").value;
$(btn).click( async function (e) { 
    var code = document.getElementById("varCode").value;
    e.preventDefault();
    var data = {"code":code , "Mail":mail};
    await $.get("verifyCheck.php", data,
        function (data) {
            if(data.pass == 0 ){
                alert("驗證碼錯誤");
            }else{
                var url;
                if(situation == "newAccount"){
                    url = `verifyPass.php?uMail=${mail}`;
                }else if (situation == "forgotPassword"){
                    url = `resetPassword.php?uMail=${mail}`;
                }else if(situation == "changePassword"){
                    url = `changePassword.php?uMail=${mail}`;
                }else if(situation == "changeInfo"){
                    url = `DoChangeInfo.php?uId=${uId}`;
                }else{
                    url="../default/";
                }
                location.href = url;
            }
        },
        "json"
    );
});