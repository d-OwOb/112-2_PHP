var isBaned = document.getElementById("isBaned").value;

if(isBaned==1){
    alert("此帳號已被禁用，無法新增文章");
    location.href= "show.php";
}

$("#submit-btn").click(async function (e) { 
    e.preventDefault();

    var semester = document.getElementById("semester").value;
    var dept = document.getElementById("dept").value;
    var classname = document.getElementById("classname").value;
    var teachername = document.getElementById("teachername").value;    
    var rate = document.getElementById("rate").value;
    var title = document.getElementById("title").value;
    var articlecontent = document.getElementById("content").value
    var msg='';
    if(rate > 5 || rate < 0 || rate=='' || ! new RegExp('[0-9]{1}[.]{0,1}').test(rate)){
        msg+="評分需介於 0.0 ~ 5.0 間\n";
    }
    if(semester == "未選擇"){
        msg+="請選擇開課學期\n";
    }
    if(dept == "未選擇"){
        msg+="請選擇開課系所\n";
    }
    if(msg!=''){
        alert(msg);
    }else{
        var data={
            "semester":semester,
            "dept":dept,
            "classname":classname,
            "teachername":teachername,
            "rating" : parseFloat(rate).toFixed(1),
            "title": title,
            "articlecontent": articlecontent
        };
        await $.post("AddDB.php", data,
            function (data) {
                alert(data.msg);
                location.href="show.php";
            },
            "json"
        ).fail(function(){
            alert("fail in js");
        });
    }
});

