var btn =document.getElementById("submit-btn");
var mail = document.getElementById("uMail").value;
var msg = "";
$(btn).click(async function (e) { 
    var pass1 = document.getElementById("pass1").value;
    var pass2 = document.getElementById("pass2").value;

    e.preventDefault();
    if(pass1 != pass2){
        msg+="密碼不一致\n";
    }else{
        uPass = pass1;

        if(uPass.length < 8){
            msg+="密碼不足8位數\n";
        }
    }

    if(msg != ""){
        alert(msg);
    }else{
        data={
            "mail" : mail , 
            "pass" : pass1 
        };
        await $.post("doReset.php", data,
            function (data) {
                alert(data.msg);
                location.href = '../default/';
            },
            "json"
        );
    }
});