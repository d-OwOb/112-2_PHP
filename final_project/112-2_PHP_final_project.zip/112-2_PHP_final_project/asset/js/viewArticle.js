$("#arti-edit-btn").click(function (e) { 
    e.preventDefault();
    var target = e.target;
    
    var url = "UpdateArticle.php?ArticleId=";
    url+=target.dataset.aid;
    location.href = url;
    
});

$("#arti-del-btn").click(function (e) { 
    e.preventDefault();
    var target = e.target;
    
    var url = "DelArticle.php?ArticleId=";
    url+=target.dataset.aid;
    if(confirm("確定要刪除此文章嗎")){
        location.href = url;
    }
    
});

$("#back-btn").click(function (e) { 
    e.preventDefault();
    window.history.back();
});