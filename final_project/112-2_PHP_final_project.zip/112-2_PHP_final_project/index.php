<?php
    header("Location: ./apps/default/");
?>